class Cal {
public :
	int getGop(int a, int b)
	{
		return a * b;
	}
};